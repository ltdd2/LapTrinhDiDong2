package com.example.recyclerviewcardview;

import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class RecyclerviewCardviewActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview_cardview);
        recyclerView =  (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),DividerItemDecoration.VERTICAL);
        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(),R.drawable.custom_divider);
        dividerItemDecoration.setDrawable(drawable);
        recyclerView.addItemDecoration(dividerItemDecoration);
        final ArrayList<DienThoai> dienThoais = new ArrayList<>();
//        dienThoais.add(new DienThoai(R.drawable.dt1,"SamSung","1000000"));
//        dienThoais.add(new DienThoai(R.drawable.dt2,"Android","200000"));
//        dienThoais.add(new DienThoai(R.drawable.dt3,"Oppo","250000"));
//        dienThoais.add(new DienThoai(R.drawable.dt4,"HTC","19500000"));
//        dienThoais.add(new DienThoai(R.drawable.dt5,"Huawei","12000000"));
   for(int i = 0 ; i < Data.txtTen.length;i++){
       dienThoais.add(new DienThoai(Data.imgHinh[i],Data.txtTen[i],Data.txtGia[i]));
   }
        final DienThoaiAdapter dienThoaiAdapter = new DienThoaiAdapter(dienThoais,getApplicationContext());
        recyclerView.setAdapter(dienThoaiAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }



}
