package com.example.recyclerviewcardview;

public class Data {
    public static String[] txtGia = {"100000","200000","300000","400000","5000000"};
    public static String[] txtTen ={"Samsung","Oppo","Huaweai","Htc","Iphone"};
    public static int[] imgHinh ={R.drawable.dt1,R.drawable.dt2,R.drawable.dt3,R.drawable.dt4,R.drawable.dt5};
}
